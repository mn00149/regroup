// index.js

var express = require('express');
var mongoose = require('mongoose');
var bodyParser = require('body-parser'); // 1
const Post = require('./model/Post');
var methodOverride = require('method-override'); // 1
var app = express();

app.use(bodyParser.json()); // 2
app.use(bodyParser.urlencoded({extended:true})); //
app.use(methodOverride('_method')); // 2
// DB setting
mongoose.set('useNewUrlParser', true);
mongoose.set('useFindAndModify', false);
mongoose.set('useCreateIndex', true);
mongoose.set('useUnifiedTopology', true);
mongoose.connect('mongodb://localhost/regroup');
var db = mongoose.connection;
db.once('open', function(){
  console.log('DB connected');
});
db.on('error', function(err){
  console.log('DB ERROR : ', err);
});

// Other settings
app.set('view engine', 'ejs');

app.get('/', (req,res) => {
res.redirect('/board')
})
// {
//   Post.find({}, (err, articles) => {
//     if(err) return res.json(err);
//     res.render('board/index',{articles:articles});   
//   })
 
// });

app.get('/board', (req, res) => {
  Post.find({})                  // 1
  .sort('-createdAt')            // 1
  .exec(function(err, articles){    // 1
    if(err) return res.json(err);
    res.render('board/index', {articles:articles});
    console.log(articles.length)
  });
});

app.post('/board', (req,res) => {
  console.log(req.body)
  Post.create(req.body, function(err, post){
    if(err) return res.json(err);
    res.render('board/index');
  });
});

app.get('/board/new', (req,res) => {
  res.render('board/new')
  })

app.get('/board/:id', function(req, res){
  Post.findOne({_id:req.params.id}, function(err, article){
    if(err) return res.json(err);
    res.render('board/show', {article:article});
  });
});



// Port setting
var port = 3000;
app.listen(port, function(){
  console.log('server on! http://localhost:'+port);
});