var mongoose = require('mongoose');

// schema
var postSchema = mongoose.Schema({ // 1
    no:{type:Number, default:0 },
  title:{type:String, required:true},
  comment:{type:String, required:true},
  author:{type:String, required:true},
  createdAt:{type:Date, default:Date.now}
 
});

// model & export
var Post = mongoose.model('post', postSchema);
module.exports = Post;
